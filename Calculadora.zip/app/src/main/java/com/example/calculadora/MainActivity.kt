package com.example.calculadora

import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), OnClickListener {

    lateinit var numeroZero: Button
    lateinit var numeroUm: Button
    lateinit var numeroDois: Button
    lateinit var numeroTres: Button
    lateinit var numeroQuatro: Button
    lateinit var numeroCinco: Button
    lateinit var numeroSeis: Button
    lateinit var numeroSete: Button
    lateinit var numeroOito: Button
    lateinit var numeroNove: Button
    lateinit var ponto: Button
    lateinit var subtracao: Button
    lateinit var multiplicacao: Button
    lateinit var divisao: Button
    lateinit var igual: Button
    lateinit var limpar: Button
    lateinit var txtExpressao: TextView
    lateinit var txtResultado: TextView

    lateinit var backspace: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        iniciarComponentes()
        supportActionBar?.hide()

        numeroZero.setOnClickListener(this)
        numeroUm.setOnClickListener(this)
        numeroDois.setOnClickListener(this)
        numeroTres.setOnClickListener(this)
        numeroQuatro.setOnClickListener(this)
        numeroCinco.setOnClickListener(this)
        numeroSeis.setOnClickListener(this)
        numeroSete.setOnClickListener(this)
        numeroOito.setOnClickListener(this)
        numeroNove.setOnClickListener(this)
        ponto.setOnClickListener(this)
        subtracao.setOnClickListener(this)
        multiplicacao.setOnClickListener(this)
        divisao.setOnClickListener(this)
        igual.setOnClickListener(this)





    }

    private fun iniciarComponentes() {
        numeroZero = findViewById(R.id.bt_num0)
        numeroUm = findViewById(R.id.bt_num1)
        numeroDois = findViewById(R.id.bt_num2)
        numeroTres = findViewById(R.id.bt_num3)
        numeroQuatro = findViewById(R.id.bt_num4)
        numeroCinco = findViewById(R.id.bt_num5)
        numeroSeis = findViewById(R.id.bt_num6)
        numeroSete = findViewById(R.id.bt_num7)
        numeroOito = findViewById(R.id.bt_num8)
        numeroNove = findViewById(R.id.bt_num9)
        ponto = findViewById(R.id.bt_ponto)
        subtracao = findViewById(R.id.bt_subtrair)
        multiplicacao = findViewById(R.id.bt_multiplicar)
        divisao = findViewById(R.id.bt_dividir)
        igual = findViewById(R.id.bt_igual)
        txtExpressao = findViewById(R.id.txt_expressao)
        txtResultado = findViewById(R.id.txt_resultado)
        backspace = findViewById(R.id.bt_apagar)
        limpar = findViewById(R.id.bt_limpar)
    }

    private fun acrescentarExpressao(string: String, limpar: Boolean) {
        if (txtResultado.text == "") {
            txtExpressao.text = ""
        }
        if (limpar) {
            txtResultado.text = ""
            txtExpressao.append(string)
        } else {
            txtExpressao.append(txtResultado.text)
            txtExpressao.append(string)
            txtResultado.text = ""
        }
    }
    private fun limparExpressao(){
        limpar.setOnClickListener {
            txtExpressao.text = ""
            txtResultado.text = ""
        }
    }

    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.bt_num0 -> acrescentarExpressao("0", true)
            R.id.bt_num1 -> acrescentarExpressao("1", true)
            R.id.bt_num2 -> acrescentarExpressao("2", true)
            R.id.bt_num3 -> acrescentarExpressao("3", true)
            R.id.bt_num4 -> acrescentarExpressao("4", true)
            R.id.bt_num5 -> acrescentarExpressao("5", true)
            R.id.bt_num6 -> acrescentarExpressao("6", true)
            R.id.bt_num7 -> acrescentarExpressao("7", true)
            R.id.bt_num8 -> acrescentarExpressao("8", true)
            R.id.bt_num9 -> acrescentarExpressao("9", true)
            R.id.bt_ponto -> acrescentarExpressao(".", true)
            R.id.bt_subtrair -> acrescentarExpressao("-", false)
            R.id.bt_multiplicar -> acrescentarExpressao("*", false)
            R.id.bt_dividir -> acrescentarExpressao("/", false)
            //R.id.bt_igual -> calcularResultado()  // Exemplo de método para calcular o resultado
            R.id.bt_limpar -> limparExpressao()   // Exemplo de método para limpar a expressão
        }
    }

}
